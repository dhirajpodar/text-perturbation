### Text Perturbation

This project is about the NLP task for text perturbation using different perturbation methods.
There are around 11 different methods.

1. "delete_random_word"
2. "replace_synonyms"
3. "backtranslation"
4. "paraphrase_using_bart"
5. "replace_with_hypernyms"
6. "random_german_word"
7. "predict_masked_word"
8. "misspelling"
9. "random_char_insertion"
10. "random_char_swaps"
11. "ocr_augmentation"


